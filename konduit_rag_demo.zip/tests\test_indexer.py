from src.indexer import chunk_text


def test_chunking():
    s = 'a' * 2000
    chunks = chunk_text(s, chunk_size=500, overlap=50)
    assert len(chunks) > 1
