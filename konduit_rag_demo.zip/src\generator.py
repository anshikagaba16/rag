import time
import json
from typing import List
from pathlib import Path
from src.utils import normalize_text


_REFUSAL_CFG = None


def _load_refusal_config():
    global _REFUSAL_CFG
    if _REFUSAL_CFG is not None:
        return _REFUSAL_CFG
    cfg_path = Path(__file__).resolve().parents[1] / 'config' / 'refusal.json'
    if cfg_path.exists():
        _REFUSAL_CFG = json.loads(cfg_path.read_text(encoding='utf-8'))
    else:
        _REFUSAL_CFG = {'threshold': 0.15, 'keywords': ['personal', 'invest', 'investment', 'investments', 'salary', 'bank', 'account', 'ssn', 'phone', 'email', 'address', 'private', 'net worth']}
    return _REFUSAL_CFG


def generate_answer(question: str, hits: List[dict]):
    """Deterministic grounded answer: concatenate top snippets. If top score is low, refuse.

    The refusal behavior is configurable via `config/refusal.json`.
    """
    t0 = time.time()
    cfg = _load_refusal_config()
    kws = cfg.get('keywords', [])
    threshold = float(cfg.get('threshold', 0.15))

    # simple personal/private detection
    ql = question.lower()
    for k in kws:
        if k in ql:
            sources = [{'url': h['url'], 'snippet': h['text'][:200]} for h in hits[:3]]
            return {'answer': 'not found in crawled content', 'sources': sources, 'generation_ms': int((time.time() - t0) * 1000)}

    # If no hits or low evidence, refuse
    if not hits:
        return {'answer': 'not found in crawled content', 'sources': [], 'generation_ms': int((time.time() - t0) * 1000)}
    best_score = hits[0].get('score', 0)
    if best_score < threshold:
        sources = [{'url': h['url'], 'snippet': h['text'][:200]} for h in hits[:3]]
        return {'answer': 'not found in crawled content', 'sources': sources, 'generation_ms': int((time.time() - t0) * 1000)}

    # Build simple answer from top snippets (shortened)
    pieces = []
    for h in hits[:3]:
        txt = normalize_text(h.get('text', ''))
        pieces.append(f"From {h.get('url')}: {txt[:300]}")

    answer = "\n\n".join(pieces)
    sources = [{'url': h['url'], 'snippet': h['text'][:200]} for h in hits[:3]]
    gen_ms = int((time.time() - t0) * 1000)
    return {'answer': answer, 'sources': sources, 'generation_ms': gen_ms}
