from src.generator import generate_answer


def make_hit(score=0.5, text='This is a snippet about Python.', url='https://example.com'):
    return {'score': score, 'text': text, 'url': url}


def test_refuse_personal():
    q = "What are Guido van Rossum's investments?"
    hits = [make_hit()]
    res = generate_answer(q, hits)
    assert res['answer'] == 'not found in crawled content'


def test_answer_when_good_evidence():
    q = 'When was Python first released?'
    hits = [make_hit(score=0.9, text='Python 1.0 was released in 1994.'), make_hit(score=0.5, text='Some other text')]
    res = generate_answer(q, hits)
    assert 'Python 1.0' in res['answer'] or res['answer'].startswith('From')
