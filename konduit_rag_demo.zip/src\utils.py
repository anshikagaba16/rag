import re
from urllib.parse import urlparse


def get_registrable_domain(url: str) -> str:
    p = urlparse(url)
    host = p.hostname or ''
    # naive registrable domain: last two labels
    parts = host.split('.')
    if len(parts) >= 2:
        return '.'.join(parts[-2:])
    return host


def normalize_text(s: str) -> str:
    s = re.sub(r'\s+', ' ', s)
    return s.strip()
