import sys
import json
from src.crawler import crawl_start
from src.indexer import index_documents
from src.retriever import ask_question


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'help'
    if cmd == 'crawl':
        payload = json.loads(sys.stdin.read() or '{}')
        print(json.dumps(crawl_start(payload), indent=2))
    elif cmd == 'index':
        payload = json.loads(sys.stdin.read() or '{}')
        print(json.dumps(index_documents(payload), indent=2))
    elif cmd == 'ask':
        payload = json.loads(sys.stdin.read() or '{}')
        print(json.dumps(ask_question(payload), indent=2))
    else:
        print('Usage: cli.py [crawl|index|ask] < payload.json')


if __name__ == '__main__':
    main()
