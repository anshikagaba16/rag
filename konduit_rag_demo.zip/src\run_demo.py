import json
import sys
from pathlib import Path

# Ensure workspace root is on sys.path so `src` package imports work
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.crawler import crawl_start
from src.indexer import index_documents
from src.retriever import ask_question


def save(name, obj):
    p = Path(name)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f'Wrote {name}')


def main():
    # Crawl a larger site (python.org) which permits crawling
    crawl_payload = {
        'start_url': 'https://www.python.org',
        'max_pages': 30,
        'max_depth': 2,
        'crawl_delay_ms': 500,
    }
    crawl_res = crawl_start(crawl_payload)
    save('demo_crawl.json', crawl_res)

    index_payload = {'chunk_size': 800, 'chunk_overlap': 100}
    index_res = index_documents(index_payload)
    save('demo_index.json', index_res)

    ask1 = {'question': 'When was Python first released?', 'top_k': 5}
    ask1_res = ask_question(ask1)
    save('demo_ask1.json', ask1_res)

    ask2 = {'question': "What are Guido van Rossum's current personal investments?", 'top_k': 5}
    ask2_res = ask_question(ask2)
    save('demo_ask2.json', ask2_res)


if __name__ == '__main__':
    main()
