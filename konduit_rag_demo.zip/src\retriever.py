import os
import time
import json
import math
from src.utils import normalize_text

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')


def dot_sparse(a: dict, b: dict) -> float:
    s = 0.0
    for k, v in a.items():
        if k in b:
            s += v * b[k]
    return s


def norm_sparse(a: dict) -> float:
    s = sum(v * v for v in a.values())
    return math.sqrt(s)


def ask_question(payload: dict):
    question = payload.get('question', '')
    top_k = int(payload.get('top_k', 5))

    meta_path = os.path.join(DATA_DIR, 'meta.json')
    if not os.path.exists(meta_path):
        return {'error': 'index not found; run /index first'}

    with open(meta_path, 'r', encoding='utf-8') as f:
        meta = json.load(f)

    texts = meta.get('texts', [])
    vectors = meta.get('vectors', [])

    # Build query vector same as indexer
    from src.indexer import tokenize, build_tfidf
    q_terms = tokenize(question)
    # Compute idf-aware tf for query using stored idf
    idf = meta.get('idf', {})
    tf = {}
    for t in q_terms:
        tf[t] = tf.get(t, 0) + 1
    qvec = {t: (count / max(1, len(q_terms))) * idf.get(t, 0.0) for t, count in tf.items()}

    t0 = time.time()
    sims = []
    for v in vectors:
        denom = (norm_sparse(v) * (norm_sparse(qvec) + 1e-12))
        if denom == 0:
            sims.append(0.0)
        else:
            sims.append(dot_sparse(v, qvec) / denom)

    idxs = sorted(range(len(sims)), key=lambda i: -sims[i])[:top_k]
    retrieval_ms = int((time.time() - t0) * 1000)

    hits = []
    metas = meta.get('meta', [])
    for idx in idxs:
        hits.append({'score': float(sims[idx]), 'text': texts[idx], 'url': metas[idx]['url']})

    res = {'retrieval_ms': retrieval_ms, 'hits': hits}
    from src.generator import generate_answer
    gen = generate_answer(question, hits)
    res.update(gen)
    res['timings'] = {'retrieval_ms': retrieval_ms, 'generation_ms': gen.get('generation_ms', 0)}
    return res
