import os
import json
import math
import re
from typing import List, Dict
from src.utils import normalize_text

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
os.makedirs(DATA_DIR, exist_ok=True)


WORD_RE = re.compile(r"\w+", re.UNICODE)


def tokenize(s: str) -> List[str]:
    return [w.lower() for w in WORD_RE.findall(s)]


def chunk_text(text: str, chunk_size: int = 800, overlap: int = 100) -> List[str]:
    """Simple character-based chunking with overlap."""
    text = normalize_text(text)
    if not text:
        return []
    n = len(text)
    if chunk_size <= 0:
        return []
    step = max(1, chunk_size - overlap)
    chunks = [text[i:i + chunk_size] for i in range(0, n, step)]
    return chunks


def build_tfidf(texts: List[str]):
    """Return idf dict and list of doc-term TF-IDF vectors (sparse dicts)."""
    docs_terms = [tokenize(t) for t in texts]
    df = {}
    for terms in docs_terms:
        seen = set()
        for t in terms:
            if t in seen:
                continue
            seen.add(t)
            df[t] = df.get(t, 0) + 1

    N = max(1, len(texts))
    idf = {t: math.log(N / (1 + df_count)) for t, df_count in df.items()}

    vectors = []
    for terms in docs_terms:
        tf = {}
        for t in terms:
            tf[t] = tf.get(t, 0) + 1
        # convert to TF-IDF
        vec = {t: (count / len(terms)) * idf.get(t, 0.0) for t, count in tf.items()}
        vectors.append(vec)
    return idf, vectors


def index_documents(payload: dict):
    """Load pages.json, chunk texts, compute TF-IDF vectors (pure python) and persist meta."""
    chunk_size = int(payload.get('chunk_size', 800))
    chunk_overlap = int(payload.get('chunk_overlap', 100))

    pages_path = os.path.join(DATA_DIR, 'pages.json')
    if not os.path.exists(pages_path):
        return {'error': 'no pages.json found; run crawl first'}

    with open(pages_path, 'r', encoding='utf-8') as f:
        pages = json.load(f)['pages']

    texts = []
    meta = []
    for p in pages:
        chunks = chunk_text(p.get('text', ''), chunk_size, chunk_overlap)
        for c in chunks:
            texts.append(c)
            meta.append({'url': p.get('url')})

    idf, vectors = build_tfidf(texts)

    with open(os.path.join(DATA_DIR, 'meta.json'), 'w', encoding='utf-8') as f:
        json.dump({'meta': meta, 'texts': texts, 'idf': idf, 'vectors': vectors}, f, ensure_ascii=False)

    return {'vector_count': len(texts), 'errors': []}
