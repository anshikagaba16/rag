import json
from pathlib import Path
import statistics
from typing import List
import argparse


def load_query_file(path: str = 'demo_queries.json') -> List[dict]:
    p = Path(path)
    if not p.exists():
        return []
    return json.loads(p.read_text(encoding='utf-8'))


def run_queries(queries: List[dict]):
    """Run queries programmatically against the local retriever/generator.

    Each query is a dict: {"question": ..., "top_k": 5}
    Returns list of results with timings.
    """
    import sys
    from pathlib import Path
    ROOT = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(ROOT))
    from src.retriever import ask_question
    results = []
    for q in queries:
        payload = {'question': q.get('question', ''), 'top_k': q.get('top_k', 5)}
        # ask_question returns retrieval_ms, hits, answer, sources, generation_ms, timings
        res = ask_question(payload)
        # normalize fields
        retrieval = res.get('retrieval_ms', res.get('timings', {}).get('retrieval_ms', 0))
        generation = res.get('generation_ms', res.get('timings', {}).get('generation_ms', 0))
        total = retrieval + generation
        results.append({
            'question': q.get('question', ''),
            'retrieval_ms': retrieval,
            'generation_ms': generation,
            'total_ms': total,
            'answer': res.get('answer'),
            'sources': res.get('sources', []),
        })
    return results


def run_queries_live(queries: List[dict], endpoint: str = 'http://127.0.0.1:8000/ask'):
    """Call the live HTTP /ask endpoint for each query. Returns same result format as run_queries."""
    import requests
    results = []
    for q in queries:
        payload = {'question': q.get('question', ''), 'top_k': q.get('top_k', 5)}
        r = requests.post(endpoint, json=payload, timeout=30)
        res = r.json()
        retrieval = res.get('retrieval_ms', res.get('timings', {}).get('retrieval_ms', 0))
        generation = res.get('generation_ms', res.get('timings', {}).get('generation_ms', 0))
        total = retrieval + generation
        results.append({
            'question': q.get('question', ''),
            'retrieval_ms': retrieval,
            'generation_ms': generation,
            'total_ms': total,
            'answer': res.get('answer'),
            'sources': res.get('sources', []),
        })
    return results


def compute_report_from_results(results: List[dict]):
    report = {}
    for key in ['retrieval_ms', 'generation_ms']:
        vals = [r.get(key, 0) for r in results if key in r]
        if not vals:
            report[key] = {'count': 0}
            continue
        vals_sorted = sorted(vals)
        p50 = statistics.median(vals_sorted)
        idx95 = max(0, int(0.95 * len(vals_sorted)) - 1)
        p95 = vals_sorted[idx95]
        report[key] = {'count': len(vals_sorted), 'p50': p50, 'p95': p95, 'min': min(vals_sorted), 'max': max(vals_sorted)}

    totals = [r.get('total_ms', 0) for r in results]
    if totals:
        totals_sorted = sorted(totals)
        p50 = statistics.median(totals_sorted)
        idx95 = max(0, int(0.95 * len(totals_sorted)) - 1)
        p95 = totals_sorted[idx95]
        report['total_ms'] = {'count': len(totals_sorted), 'p50': p50, 'p95': p95, 'min': min(totals_sorted), 'max': max(totals_sorted)}
    else:
        report['total_ms'] = {'count': 0}

    return report


def compute_recall_at_k(results: List[dict], k: int = 5):
    """Compute recall@k when results include 'sources' and queries include 'expected_urls' entry.

    Expect queries to contain 'expected_urls' as list of ground-truth urls.
    """
    import re
    from urllib.parse import urlparse

    def normalize(u: str) -> str:
        if not u:
            return ''
        u = u.strip()
        # ensure scheme
        if not re.match(r'https?://', u):
            u = 'http://' + u
        return u

    def host_and_path(u: str):
        try:
            p = urlparse(normalize(u))
            host = p.hostname or ''
            # drop leading www.
            if host.startswith('www.'):
                host = host[4:]
            path = (p.path or '').rstrip('/')
            return host.lower(), path.lower()
        except Exception:
            return u.lower(), ''

    def matches(expected_url: str, retrieved_url: str) -> bool:
        eh, ep = host_and_path(expected_url)
        rh, rp = host_and_path(retrieved_url)
        if not eh or not rh:
            return False
        # exact host match or expected host contained in retrieved host
        if eh == rh or eh in rh or rh in eh:
            # if expected path is empty, host match is enough
            if not ep:
                return True
            # accept if expected path is substring of retrieved path
            if ep in rp or rp in ep:
                return True
        # fallback: check if expected host is a substring of retrieved url string
        if eh and eh in retrieved_url.lower():
            return True
        return False

    recalls = []
    for r in results:
        expected = r.get('expected_urls') or []
        if not expected:
            continue
        retrieved_urls = [s.get('url') for s in r.get('sources', [])][:k]
        hit = False
        for e in expected:
            for rv in retrieved_urls:
                if matches(e, rv):
                    hit = True
                    break
            if hit:
                break
        recalls.append(1.0 if hit else 0.0)
    if not recalls:
        return {'count': 0}
    return {'count': len(recalls), 'recall@{}'.format(k): sum(recalls) / len(recalls)}


def write_outputs(results: List[dict], report: dict):
    Path('metrics_report.json').write_text(json.dumps({'report': report, 'samples': len(results)}, indent=2), encoding='utf-8')
    # write CSV lines
    import csv
    with open('metrics_details.csv', 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['question', 'retrieval_ms', 'generation_ms', 'total_ms', 'answer', 'sources'])
        for r in results:
            w.writerow([r['question'], r['retrieval_ms'], r['generation_ms'], r['total_ms'], (r.get('answer') or '')[:200], ';'.join([s.get('url','') for s in r.get('sources',[] )]) ])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true', help='Call the live HTTP /ask endpoint instead of local functions')
    parser.add_argument('--endpoint', type=str, default='http://127.0.0.1:8000/ask', help='Live /ask endpoint')
    parser.add_argument('--eval', type=str, default='', help='Optional eval file with expected_urls per query')
    args = parser.parse_args()

    queries = load_query_file()
    if not queries:
        print('No queries found in demo_queries.json; falling back to demo_ask*.json')
        # fallback: load demo_ask files
        p = Path('.').glob('demo_ask*.json')
        results = []
        for f in p:
            try:
                j = json.loads(f.read_text(encoding='utf-8'))
                retrieval = j.get('retrieval_ms', j.get('timings', {}).get('retrieval_ms', 0))
                generation = j.get('generation_ms', j.get('timings', {}).get('generation_ms', 0))
                total = retrieval + generation
                results.append({'question': j.get('question', ''), 'retrieval_ms': retrieval, 'generation_ms': generation, 'total_ms': total, 'answer': j.get('answer'), 'sources': j.get('sources', [])})
            except Exception:
                continue
        report = compute_report_from_results(results)
        write_outputs(results, report)
        print('Wrote metrics_report.json and metrics_details.csv (from demo_ask files)')
        return

    if args.live:
        results = run_queries_live(queries, endpoint=args.endpoint)
    else:
        results = run_queries(queries)
    # attach expected_urls if eval file provided
    if args.eval:
        evalp = Path(args.eval)
        if evalp.exists():
            evals = json.loads(evalp.read_text(encoding='utf-8'))
            # evals expected to be list of {question, expected_urls}
            for r in results:
                for e in evals:
                    if e.get('question') == r.get('question'):
                        r['expected_urls'] = e.get('expected_urls', [])
                        break
    report = compute_report_from_results(results)
    write_outputs(results, report)
    recall = compute_recall_at_k(results, k=5)
    # add recall to report file
    out = json.loads(Path('metrics_report.json').read_text(encoding='utf-8'))
    out['recall'] = recall
    Path('metrics_report.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
    print('Wrote metrics_report.json and metrics_details.csv (from queries)')


if __name__ == '__main__':
    main()
