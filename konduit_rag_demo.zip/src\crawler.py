import time
import json
import os
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from robotexclusionrulesparser import RobotExclusionRulesParser
from src.utils import get_registrable_domain, normalize_text

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
os.makedirs(DATA_DIR, exist_ok=True)


def fetch_robots(base_url: str):
    try:
        r = requests.get(urljoin(base_url, '/robots.txt'), timeout=5)
        parser = RobotExclusionRulesParser()
        parser.parse(r.text)
        return parser
    except Exception:
        return None


def extract_main_text(html: str) -> str:
    soup = BeautifulSoup(html, 'html.parser')
    # remove scripts and styles
    for s in soup(['script', 'style', 'noscript', 'header', 'footer', 'nav', 'form']):
        s.decompose()
    # heuristic: prefer article tags
    article = soup.find('article')
    if article:
        text = article.get_text(' ', strip=True)
    else:
        # fallback: join paragraphs
        ps = soup.find_all('p')
        if ps:
            text = ' '.join(p.get_text(' ', strip=True) for p in ps)
        else:
            text = soup.get_text(' ', strip=True)
    return normalize_text(text)


def crawl_start(payload: dict):
    start_url = payload.get('start_url')
    max_pages = int(payload.get('max_pages', 30))
    max_depth = int(payload.get('max_depth', 3))
    crawl_delay_ms = int(payload.get('crawl_delay_ms', 500))

    if not start_url:
        return {'error': 'start_url required'}

    domain = get_registrable_domain(start_url)
    robots = fetch_robots(start_url)

    to_visit = [(start_url, 0)]
    visited = set()
    docs = {}
    skipped = 0

    while to_visit and len(docs) < max_pages:
        url, depth = to_visit.pop(0)
        if url in visited:
            continue
        visited.add(url)
        parsed = urlparse(url)
        if get_registrable_domain(url) != domain:
            skipped += 1
            continue

        # robots check
        try:
            if robots and not robots.is_allowed('*', url):
                skipped += 1
                continue
        except Exception:
            pass

        try:
            r = requests.get(url, timeout=8)
            if 'text/html' not in r.headers.get('Content-Type', ''):
                skipped += 1
                continue
            text = extract_main_text(r.text)
            docs[url] = {'url': url, 'text': text}

            if depth < max_depth:
                soup = BeautifulSoup(r.text, 'html.parser')
                for a in soup.find_all('a', href=True):
                    href = a['href']
                    nxt = urljoin(url, href)
                    if urlparse(nxt).scheme.startswith('http'):
                        to_visit.append((nxt, depth + 1))
        except Exception:
            skipped += 1
        time.sleep(crawl_delay_ms / 1000.0)

    # persist
    out_path = os.path.join(DATA_DIR, 'pages.json')
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump({'pages': list(docs.values())}, f, ensure_ascii=False, indent=2)

    return {'page_count': len(docs), 'skipped_count': skipped, 'urls': list(docs.keys())}
